'use strict';
/* FreelanceFin – vanilla JS demo. All data lives in localStorage under KEY. */
const KEY = 'freelancefin-v1', STAT = ['Active', 'On hold', 'Completed'];
const $ = (s, r = document) => r.querySelector(s);
const sum = a => a.reduce((x, y) => x + y.amount, 0);
const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const inr = n => '₹' + Math.round(n).toLocaleString('en-IN');
const p2 = n => String(n).padStart(2, '0');
const fmt = d => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
const off = n => { const d = new Date(); d.setDate(d.getDate() + n); return fmt(d); };
const mk = i => { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i); return fmt(d).slice(0, 7); }; // month key, i months ago
const today = () => off(0), uid = () => Math.random().toString(36).slice(2, 9);
const ym = d => d.slice(0, 7), MS = [5, 4, 3, 2, 1, 0].map(mk);

/* ---------- Data ---------- */
function sample() {
  const inc = [62000, 48000, 71000, 55000, 66000, 59000], t = [];
  inc.forEach((v, i) => { const d = mk(i) + '-02', x = (type, cat, amount) => t.push({ id: uid(), type, cat, amount, date: d, note: '' });
    x('income', 'Project payment', v); x('expense', 'Cowork space', 9000); x('expense', 'Software', 3000 + i * 400);
    x('expense', 'Marketing', 2000 + (i % 3) * 1500); x('expense', 'Travel', 1500 + (i % 2) * 2500); });
  return {
    clients: [
      { id: 'c1', name: 'Asha Textiles', company: 'Asha Textiles Pvt Ltd', email: 'accounts@asha.example', phone: '+91 98765 43210' },
      { id: 'c2', name: 'Brightside Cafe', company: 'Brightside Hospitality', email: 'hello@brightside.example', phone: '+91 91234 56780' },
      { id: 'c3', name: 'Kiran Rao', company: '', email: 'kiran@example.com', phone: '' }],
    projects: [
      { id: 'p1', name: 'Brand website', clientId: 'c1', deadline: off(20), amount: 120000, budget: 0, manager: 'Ravi', status: 'Active', tasks: 4 },
      { id: 'p2', name: 'Mobile app UI', clientId: 'c2', deadline: off(45), amount: 0, budget: 90000, manager: 'Meera', status: 'Active', tasks: 6 },
      { id: 'p3', name: 'Logo refresh', clientId: 'c3', deadline: off(-5), amount: 40000, budget: 0, manager: 'Sam', status: 'Completed', tasks: 0 }],
    invoices: [
      { id: 'i1', no: 'INV-001', clientId: 'c1', projectId: 'p1', issue: off(-40), due: off(-10), tax: 18, paid: false, items: [{ d: 'Website design', amt: 60000 }, { d: 'Development (phase 1)', amt: 40000 }] },
      { id: 'i2', no: 'INV-002', clientId: 'c3', projectId: 'p3', issue: off(-30), due: off(-16), tax: 0, paid: true, items: [{ d: 'Logo refresh', amt: 40000 }] },
      { id: 'i3', no: 'INV-003', clientId: 'c2', projectId: 'p2', issue: off(-3), due: off(11), tax: 18, paid: false, items: [{ d: 'UI design – advance', amt: 30000 }] }],
    txns: t, set: { savings: 150000, emi: 8000 }
  };
}
const empty = () => ({ clients: [], projects: [], invoices: [], txns: [], set: { savings: 0, emi: 0 } });
let S, tab = 'overview';
try { S = JSON.parse(localStorage.getItem(KEY)) || sample(); } catch { S = sample(); }
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* storage blocked */ } };
const cl = id => S.clients.find(c => c.id === id) || { name: '—' };
const pr = id => S.projects.find(p => p.id === id);
const inv$ = i => Math.round(i.items.reduce((a, x) => a + x.amt, 0) * (1 + i.tax / 100) * 100) / 100; // subtotal + tax
const invStatus = i => i.paid ? 'Paid' : i.due < today() ? 'Overdue' : 'Unpaid';   // overdue = unpaid and past due date
const month = (m, type) => S.txns.filter(t => ym(t.date) === m && (!type || t.type === type));
const group = a => a.reduce((o, t) => (o[t.cat] = (o[t.cat] || 0) + t.amount, o), {});
let tm; const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tm); tm = setTimeout(() => t.classList.remove('on'), 2500); };

/* ---------- UI helpers ---------- */
const tbl = (heads, rows, msg) => rows ? `<div class="scroll"><table><thead><tr>${heads.map(h => `<th scope="col">${h}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div>` : `<p class="empty">${msg}</p>`;
const btn = (act, id, label, cls = 'sec') => `<button class="${cls}" data-act="${act}" data-id="${id}">${label}</button>`;
const kpi = (l, v, c = '') => `<div class="kpi"><span>${l}</span><strong class="${c}">${v}</strong></div>`;

function openForm(title, fields, v, cb) {
  const d = $('#dlg');
  d.innerHTML = `<form novalidate><h2>${title}</h2>${fields.map(f => {
    const val = v[f.n] ?? '', id = 'f_' + f.n; let c;
    if (f.t === 'select') c = `<select id="${id}" name="${f.n}">${f.o.map(([a, b]) => `<option value="${esc(a)}"${a == val ? ' selected' : ''}>${esc(b)}</option>`).join('')}</select>`;
    else if (f.t === 'textarea') c = `<textarea id="${id}" name="${f.n}" rows="4" placeholder="${esc(f.ph || '')}">${esc(val)}</textarea>`;
    else c = `<input id="${id}" name="${f.n}" type="${f.t || 'text'}" value="${esc(val)}" ${f.t === 'number' ? 'min="0" step="any"' : ''} ${f.dl ? `list="dl_${f.n}"` : ''}>${f.dl ? `<datalist id="dl_${f.n}">${f.dl.map(x => `<option>${x}</option>`).join('')}</datalist>` : ''}`;
    return `<label for="${id}">${f.l}${f.r ? ' *' : ''}</label>${c}`;
  }).join('')}<p class="err" role="alert"></p><div class="row"><button type="submit">Save</button><button type="button" class="sec" data-act="close">Cancel</button></div></form>`;
  const form = $('form', d);
  form.onsubmit = e => {
    e.preventDefault(); const o = Object.fromEntries(new FormData(form));
    const bad = fields.find(f => (f.r && !String(o[f.n]).trim()) || (f.t === 'number' && o[f.n] !== '' && !(+o[f.n] >= 0)));
    if (bad) { $('.err', d).textContent = `Please enter a valid "${bad.l}".`; return; }
    const msg = cb(o); if (msg) { $('.err', d).textContent = msg; return; }
    d.close(); save(); render();
  };
  d.showModal();
}
function showDoc(html) {
  const d = $('#dlg'); d.innerHTML = `<div class="doc">${html}</div><div class="row"><button data-act="print">Print / Save as PDF</button><button class="sec" data-act="close">Close</button></div>`; d.showModal();
}

/* ---------- Views ---------- */
const V = {};
V.overview = () => {
  const m = mk(0), inc = sum(month(m, 'income')), exp = sum(month(m, 'expense')), act = S.projects.filter(p => p.status === 'Active');
  const un = S.invoices.filter(i => !i.paid), od = un.filter(i => invStatus(i) === 'Overdue');
  const d = MS.map(k => [sum(month(k, 'income')), sum(month(k, 'expense'))]), mx = Math.max(1, ...d.flat());
  const svg = `<svg viewBox="0 0 600 215" role="img" aria-label="Income and expenses for the last 6 months">` + d.map(([i, e], k) => {
    const x = 20 + k * 95, hi = i / mx * 160, he = e / mx * 160;
    return `<rect x="${x}" y="${180 - hi}" width="36" height="${hi}" fill="var(--g)"><title>Income ${inr(i)}</title></rect><rect x="${x + 40}" y="${180 - he}" width="36" height="${he}" fill="var(--r)"><title>Expenses ${inr(e)}</title></rect><text x="${x + 38}" y="200" text-anchor="middle">${MS[k]}</text>`;
  }).join('') + `</svg><p class="legend"><i class="g"></i>Income<i class="r"></i>Expenses</p>`;
  return `<h2>Overview</h2><div class="kpis">${kpi('Active projects', act.length)}${kpi('Pending tasks', act.reduce((a, p) => a + (+p.tasks || 0), 0))}
  ${kpi('Unpaid invoices', `${un.length} · ${inr(un.reduce((a, i) => a + inv$(i), 0))}`)}${kpi('Overdue invoices', `${od.length} · ${inr(od.reduce((a, i) => a + inv$(i), 0))}`, od.length ? 'neg' : '')}
  ${kpi('Income (this month)', inr(inc), 'pos')}${kpi('Expenses (this month)', inr(exp), 'neg')}${kpi('Estimated profit', inr(inc - exp), inc - exp >= 0 ? 'pos' : 'neg')}</div>
  <section class="card"><h2>Last 6 months</h2>${svg}<p class="note">Estimated profit = income − expenses (recorded transactions only, before tax).</p></section>`;
};
V.clients = () => `<div class="card"><div class="bar"><h2>Clients</h2>${btn('addClient', '', 'Add client', '')}</div>
  ${tbl(['Client', 'Contact', 'Projects', ''], S.clients.map(c => `<tr><td><strong>${esc(c.name)}</strong><br><small>${esc(c.company)}</small></td><td>${esc(c.email)}<br><small>${esc(c.phone)}</small></td><td>${S.projects.filter(p => p.clientId === c.id).length}</td><td>${btn('editClient', c.id, 'Edit')}</td></tr>`).join(''), 'No clients yet. Add your first client.')}</div>
  <div class="card"><div class="bar"><h2>Projects</h2>${btn('addProject', '', 'Add project', '')}</div>
  ${tbl(['Project', 'Client', 'Deadline', 'Value', 'Manager', 'Status', 'Pending tasks', ''], S.projects.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(cl(p.clientId).name)}</td><td>${p.deadline || '—'}</td><td>${p.amount ? inr(p.amount) : p.budget ? 'Est. ' + inr(p.budget) : '—'}</td><td>${esc(p.manager)}</td>
  <td><select data-status="${p.id}" aria-label="Status of ${esc(p.name)}">${STAT.map(s => `<option${s === p.status ? ' selected' : ''}>${s}</option>`).join('')}</select></td><td>${p.tasks}</td><td>${btn('editProject', p.id, 'Edit')}</td></tr>`).join(''), 'No projects yet. Add a client first, then create a project.')}</div>`;
V.invoices = () => `<div class="card"><div class="bar"><h2>Invoices</h2>${btn('addInvoice', '', 'Create invoice', '')}</div>
  ${tbl(['No.', 'Client / project', 'Due', 'Total', 'Status', ''], [...S.invoices].reverse().map(i => `<tr><td>${esc(i.no)}</td><td>${esc(cl(i.clientId).name)}<br><small>${esc(pr(i.projectId)?.name || '')}</small></td><td>${i.due}</td><td>${inr(inv$(i))}</td><td><span class="badge ${invStatus(i)}">${invStatus(i)}</span></td>
  <td>${btn('togglePaid', i.id, i.paid ? 'Mark unpaid' : 'Mark paid')} ${btn('viewInv', i.id, 'View / PDF')} ${btn('delInv', i.id, 'Delete')}</td></tr>`).join(''), 'No invoices yet.')}
  <p class="note">Marking an invoice paid records an income entry automatically.</p></div>`;
V.money = () => {
  const m3 = MS.slice(3), ex = group(m3.flatMap(m => month(m, 'expense'))), tot = Object.values(ex).reduce((a, b) => a + b, 0);
  const cats = Object.entries(ex).sort((a, b) => b[1] - a[1]);
  const e2 = sum(month(MS[4], 'expense')), e1 = sum(month(MS[5], 'expense')), ch = e2 ? (e1 - e2) / e2 * 100 : 0;
  const insight = cats.length ? `Your biggest expense is ${esc(cats[0][0])} (${Math.round(cats[0][1] / tot * 100)}% of the last 3 months). Spending this month vs last: ${ch >= 0 ? '+' : ''}${Math.round(ch)}%.` : '';
  return `<div class="card"><div class="bar"><h2>Income &amp; expenses</h2><div class="row" style="margin:0">${btn('addTxn', '', 'Add transaction', '')}${btn('report', '', 'Income report (PDF)')}</div></div>
  ${tbl(['Month', 'Income', 'Expenses', 'Est. profit'], [...MS].reverse().map(m => { const i = sum(month(m, 'income')), e = sum(month(m, 'expense')); return `<tr><td>${m}</td><td class="pos">${inr(i)}</td><td class="neg">${inr(e)}</td><td>${inr(i - e)}</td></tr>`; }).join(''), '')}</div>
  <div class="card"><h2>Spending patterns (last 3 months)</h2>${cats.length ? `<p>${insight}</p>` + cats.map(([c, v]) => `<p style="margin:.4rem 0 .1rem">${esc(c)} — ${inr(v)} (${Math.round(v / tot * 100)}%)</p><div class="meter"><i style="width:${v / tot * 100}%"></i></div>`).join('') : '<p class="empty">No expenses recorded yet.</p>'}</div>
  <div class="card"><h2>Recent transactions</h2>${tbl(['Date', 'Type', 'Category', 'Amount', ''], [...S.txns].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 15).map(t => `<tr><td>${t.date}</td><td>${t.type}</td><td>${esc(t.cat)}<br><small>${esc(t.note)}</small></td><td class="${t.type === 'income' ? 'pos' : 'neg'}">${inr(t.amount)}</td><td>${btn('delTxn', t.id, 'Delete')}</td></tr>`).join(''), 'No transactions yet.')}</div>`;
};
V.rate = () => `<section class="card"><h2>Smart rate calculator</h2><div class="grid2"><form id="rf" onsubmit="return false">${[
  ['target', 'Target annual income (₹)', 1200000], ['over', 'Annual business expenses (₹)', 120000], ['hpw', 'Working hours per week', 40],
  ['dpw', 'Working days per week', 5], ['off', 'Weeks of time off / holidays per year', 6], ['nb', 'Non-billable time (% of working hours)', 25]
].map(([n, l, v]) => `<label for="r_${n}">${l}</label><input id="r_${n}" type="number" min="0" step="any" value="${v}">`).join('')}</form><div id="rout" aria-live="polite"></div></div></section>`;
V.loan = () => `<section class="card"><h2>Loan readiness</h2><p class="note"><strong>Educational estimate only.</strong> This is not a bank decision, loan offer or guarantee of approval. No credit bureau or bank data is used – only the transactions you recorded here.</p>
  <div class="grid2"><div><label for="l_sav">Current savings (₹)</label><input id="l_sav" type="number" min="0" value="${S.set.savings}"></div><div><label for="l_emi">Existing monthly EMI / debt payments (₹)</label><input id="l_emi" type="number" min="0" value="${S.set.emi}"></div></div></section><div id="lout" aria-live="polite"></div>`;

/* ---------- Calculators ---------- */
function calcRate() {
  const g = n => Math.max(0, +$('#r_' + n).value || 0), w = 52 - g('off');
  const bh = w * g('hpw') * (1 - Math.min(g('nb'), 100) / 100), bd = w * g('dpw') * (1 - Math.min(g('nb'), 100) / 100), need = g('target') + g('over');
  $('#rout').innerHTML = bh > 0 && bd > 0 ? `<h3>Suggested rate</h3><p class="grade">${inr(need / bh)}<small> / hour</small></p><p><strong>${inr(need / bd)}</strong> per day</p>
  <h3>Formula</h3><p>Working weeks = 52 − ${g('off')} = ${w}<br>Billable hours = ${w} × ${g('hpw')} × (1 − ${g('nb')}%) = ${Math.round(bh)}<br>Billable days = ${w} × ${g('dpw')} × (1 − ${g('nb')}%) = ${Math.round(bd)}<br>Income needed = target + expenses = ${inr(need)}<br>Hourly = ${inr(need)} ÷ ${Math.round(bh)}; Daily = ${inr(need)} ÷ ${Math.round(bd)}</p><p class="note">Taxes are not included – add them if your target is take-home.</p>` : '<p class="empty">Enter valid working weeks, hours and days.</p>';
}
function calcLoan() {
  S.set.savings = +$('#l_sav').value || 0; S.set.emi = +$('#l_emi').value || 0; save();
  const inc = MS.map(m => sum(month(m, 'income'))), exp = MS.map(m => sum(month(m, 'expense'))), aI = avg(inc), aE = avg(exp), prof = aI - aE;
  const cv = aI ? Math.sqrt(avg(inc.map(x => (x - aI) ** 2))) / aI : 1;      // income variability (std dev ÷ mean)
  const cover = aE ? S.set.savings / aE : 0, dti = aI ? S.set.emi / aI : 1, margin = aI ? prof / aI : 0;
  const e1 = avg(exp.slice(0, 3)), trend = e1 ? (avg(exp.slice(3)) - e1) / e1 : 0;
  const F = [
    ['Income stability', cv < .2 ? 2 : cv < .4 ? 1 : 0, 2, `Variation ${Math.round(cv * 100)}% (≤20% = 2 pts, ≤40% = 1)`, 'Aim for retainers or repeat clients to even out monthly income.'],
    ['Savings buffer', cover >= 6 ? 2 : cover >= 3 ? 1 : 0, 2, `${cover.toFixed(1)} months of expenses (≥6 = 2 pts, ≥3 = 1)`, 'Build savings toward 6 months of expenses.'],
    ['Existing debt', dti <= .2 ? 2 : dti <= .4 ? 1 : 0, 2, `EMIs are ${Math.round(dti * 100)}% of income (≤20% = 2 pts, ≤40% = 1)`, 'Pay down existing EMIs before taking new debt.'],
    ['Profit margin', margin >= .3 ? 2 : margin >= .15 ? 1 : 0, 2, `${Math.round(margin * 100)}% of income (≥30% = 2 pts, ≥15% = 1)`, 'Review expenses or raise your rates (see Rate Calculator).'],
    ['Expense trend', trend <= .1 ? 1 : 0, 1, `Last 3 vs previous 3 months: ${trend >= 0 ? '+' : ''}${Math.round(trend * 100)}% (≤+10% = 1 pt)`, 'Keep recent spending flat or falling.']];
  const pts = F.reduce((a, f) => a + f[1], 0), grade = pts >= 7 ? 'A' : pts >= 5 ? 'B' : pts >= 3 ? 'C' : 'D';
  // Sustainable EMI = 20%–35% of average monthly profit, minus existing EMIs (assumption)
  const lo = Math.max(0, .2 * prof - S.set.emi), hi = Math.max(0, .35 * prof - S.set.emi), mid = (lo + hi) / 2;
  const principal = (r, y) => { const i = r / 1200, n = y * 12; return mid * (1 - Math.pow(1 + i, -n)) / i; }; // EMI = P·i/(1−(1+i)^−n)  →  P = EMI·(1−(1+i)^−n)/i
  $('#lout').innerHTML = `<section class="card"><h2>Summary (last 6 months)</h2><div class="kpis">${kpi('Avg monthly income', inr(aI))}${kpi('Avg monthly expenses', inr(aE))}${kpi('Avg monthly profit', inr(prof), prof >= 0 ? 'pos' : 'neg')}${kpi('Savings cover', cover.toFixed(1) + ' months')}</div>
  <div class="grid2"><div><h3>Indicative risk grade</h3><p class="grade" aria-label="Grade ${grade}">${grade} <small>(${pts}/9 points)</small></p><p class="note">A = 7–9, B = 5–6, C = 3–4, D = 0–2. Simple rules, not a credit score.</p></div>
  <div><h3>Sustainable EMI range</h3><p class="grade">${inr(lo)} – ${inr(hi)}</p><p class="note">20%–35% of average monthly profit (${inr(prof)}) minus existing EMIs (${inr(S.set.emi)}).</p></div></div></section>
  <section class="card"><h2>Example loan scenarios</h2>${mid > 0 ? tbl(['Interest rate (assumed)', 'Tenure', 'EMI used', 'Illustrative loan amount'], [[10, 3], [10, 5], [13, 3], [13, 5]].map(([r, y]) => `<tr><td>${r}% p.a.</td><td>${y} years</td><td>${inr(mid)}</td><td>${inr(principal(r, y))}</td></tr>`).join(''), '') + '<p class="note">Assumes the midpoint of your EMI range, fixed rates and standard reducing-balance EMIs. Real lenders use their own rules.</p>' : '<p class="empty">No sustainable EMI capacity at current profit and debt levels.</p>'}</section>
  <section class="card"><h2>What affected the estimate</h2>${tbl(['Factor', 'Points', 'Detail', 'How to improve'], F.map(f => `<tr><td>${f[0]}</td><td>${f[1]}/${f[2]}</td><td>${f[3]}</td><td>${f[1] < f[2] ? f[4] : '✓ Good'}</td></tr>`).join(''), '')}</section>`;
}
function reportHtml() {
  const i6 = MS.flatMap(m => month(m, 'income')), tot = sum(i6), c = Object.entries(group(i6));
  return `<h2>Income summary report</h2><p>Generated ${today()} · last 6 months</p>${tbl(['Month', 'Income', 'Expenses', 'Est. profit'], MS.map(m => { const i = sum(month(m, 'income')), e = sum(month(m, 'expense')); return `<tr><td>${m}</td><td>${inr(i)}</td><td>${inr(e)}</td><td>${inr(i - e)}</td></tr>`; }).join(''), '')}<h3>Income by category</h3>${tbl(['Category', 'Amount'], c.map(([k, v]) => `<tr><td>${esc(k)}</td><td>${inr(v)}</td></tr>`).join(''), 'No income recorded.')}<p><strong>Total income: ${inr(tot)}</strong></p>`;
}
function invDoc(i) {
  const c = S.clients.find(x => x.id === i.clientId) || {}, p = pr(i.projectId), sub = i.items.reduce((a, x) => a + x.amt, 0);
  return `<article class="inv"><header><div><h2>INVOICE</h2>${esc(i.no)}</div><div class="r"><strong>Your Business</strong><br>Status: ${invStatus(i)}</div></header>
  <div class="two"><div><h3>Bill to</h3>${esc(c.name)}<br>${esc(c.company || '')}<br>${esc(c.email || '')}</div><div>Issued: ${i.issue}<br>Due: ${i.due}<br>Project: ${esc(p?.name || '—')}</div></div>
  ${tbl(['Description', 'Amount'], i.items.map(x => `<tr><td>${esc(x.d)}</td><td>${inr(x.amt)}</td></tr>`).join(''), '')}
  <p class="r">Subtotal: ${inr(sub)}<br>Tax (${i.tax}%): ${inr(sub * i.tax / 100)}<br><strong>Total: ${inr(inv$(i))}</strong></p></article>`;
}

/* ---------- Actions ---------- */
const CF = [{ n: 'name', l: 'Name', r: 1 }, { n: 'company', l: 'Company' }, { n: 'email', l: 'Email', t: 'email' }, { n: 'phone', l: 'Phone', t: 'tel' }];
const projF = () => [{ n: 'name', l: 'Project name', r: 1 }, { n: 'clientId', l: 'Client', t: 'select', o: S.clients.map(c => [c.id, c.name]) }, { n: 'deadline', l: 'Deadline', t: 'date' },
  { n: 'amount', l: 'Agreed amount (₹)', t: 'number' }, { n: 'budget', l: 'Budget estimate (₹) – if no agreed amount', t: 'number' }, { n: 'manager', l: 'Project manager' },
  { n: 'status', l: 'Status', t: 'select', o: STAT.map(s => [s, s]) }, { n: 'tasks', l: 'Pending tasks', t: 'number' }];
const num = o => { ['amount', 'budget', 'tasks'].forEach(k => o[k] = +o[k] || 0); return o; };
const TXF = [{ n: 'type', l: 'Type', t: 'select', o: [['income', 'Income'], ['expense', 'Expense']] }, { n: 'cat', l: 'Category', r: 1, dl: ['Project payment', 'Retainer', 'Software', 'Cowork space', 'Marketing', 'Travel', 'Equipment', 'Taxes'] },
  { n: 'amount', l: 'Amount (₹)', t: 'number', r: 1 }, { n: 'date', l: 'Date', t: 'date', r: 1 }, { n: 'note', l: 'Note' }];
const A = {
  close: () => $('#dlg').close(),
  print: () => { $('#print').innerHTML = $('#dlg .doc').innerHTML; window.print(); },
  addClient: () => openForm('Add client', CF, {}, o => { S.clients.push({ id: uid(), ...o }); toast('Client added'); }),
  editClient: id => openForm('Edit client', CF, cl(id), o => { Object.assign(cl(id), o); toast('Client updated'); }),
  addProject: () => S.clients.length ? openForm('Add project', projF(), { status: 'Active' }, o => { S.projects.push({ id: uid(), ...num(o) }); toast('Project added'); }) : toast('Add a client first'),
  editProject: id => openForm('Edit project', projF(), pr(id), o => { Object.assign(pr(id), num(o)); toast('Project updated'); }),
  addInvoice: () => {
    if (!S.clients.length) return toast('Add a client first');
    const f = [{ n: 'clientId', l: 'Client', t: 'select', o: S.clients.map(c => [c.id, c.name]) }, { n: 'projectId', l: 'Project', t: 'select', o: [['', '— none —'], ...S.projects.map(p => [p.id, `${p.name} (${cl(p.clientId).name})`])] },
      { n: 'no', l: 'Invoice number', r: 1 }, { n: 'issue', l: 'Issue date', t: 'date', r: 1 }, { n: 'due', l: 'Due date', t: 'date', r: 1 },
      { n: 'items', l: 'Line items (one per line: description | amount)', t: 'textarea', r: 1, ph: 'Website design | 50000' }, { n: 'tax', l: 'Tax (%)', t: 'number' }];
    openForm('Create invoice', f, { no: 'INV-' + String(S.invoices.length + 1).padStart(3, '0'), issue: today(), due: off(14), tax: 0 }, o => {
      const items = o.items.split('\n').map(l => l.trim()).filter(Boolean).map(l => { const [d, a] = l.split('|'); return { d: (d || '').trim(), amt: +(a || '').replace(/,/g, '') }; });
      if (items.some(x => !x.d || !(x.amt > 0))) return 'Each line must look like: description | amount (amount above 0).';
      if (o.due < o.issue) return 'Due date cannot be before the issue date.';
      if (o.projectId && pr(o.projectId).clientId !== o.clientId) return 'The selected project belongs to a different client.';
      if (S.invoices.some(i => i.no === o.no)) return 'Invoice number already exists.';
      S.invoices.push({ id: uid(), no: o.no, clientId: o.clientId, projectId: o.projectId, issue: o.issue, due: o.due, tax: +o.tax || 0, paid: false, items }); toast('Invoice created');
    });
  },
  togglePaid: id => { const i = S.invoices.find(x => x.id === id); i.paid = !i.paid; S.txns = S.txns.filter(t => t.inv !== id);
    if (i.paid) S.txns.push({ id: uid(), type: 'income', cat: 'Invoice payment', amount: inv$(i), date: today(), note: i.no, inv: id }); save(); render(); toast(i.paid ? 'Marked paid – income recorded' : 'Marked unpaid'); },
  viewInv: id => showDoc(invDoc(S.invoices.find(x => x.id === id))),
  delInv: id => { if (confirm('Delete this invoice?')) { S.invoices = S.invoices.filter(i => i.id !== id); S.txns = S.txns.filter(t => t.inv !== id); save(); render(); toast('Invoice deleted'); } },
  addTxn: () => openForm('Add transaction', TXF, { type: 'income', date: today() }, o => { S.txns.push({ id: uid(), ...o, amount: +o.amount }); toast('Transaction saved'); }),
  delTxn: id => { S.txns = S.txns.filter(t => t.id !== id); save(); render(); toast('Transaction deleted'); },
  report: () => showDoc(reportHtml())
};

/* ---------- Wiring ---------- */
const TABS = [['overview', 'Overview'], ['clients', 'Clients & Projects'], ['invoices', 'Invoices'], ['money', 'Income & Expenses'], ['rate', 'Rate Calculator'], ['loan', 'Loan Readiness']];
function render() {
  $('#nav').innerHTML = TABS.map(([k, l]) => `<button type="button" data-tab="${k}" aria-current="${k === tab}">${l}</button>`).join('');
  $('#main').innerHTML = V[tab]();
  if (tab === 'rate') calcRate(); if (tab === 'loan') calcLoan();
}
document.addEventListener('click', e => {
  const t = e.target.closest('[data-tab],[data-act]'); if (!t) return;
  if (t.dataset.tab) { tab = t.dataset.tab; render(); } else A[t.dataset.act]?.(t.dataset.id);
});
document.addEventListener('change', e => {
  const t = e.target; if (t.dataset.status) { pr(t.dataset.status).status = t.value; save(); render(); toast('Status updated'); }
});
document.addEventListener('input', e => { if (e.target.id?.startsWith('r_')) calcRate(); if (e.target.id?.startsWith('l_')) calcLoan(); });
$('#load').onclick = () => { if (confirm('Replace current data with sample data?')) { S = sample(); save(); render(); toast('Sample data loaded'); } };
$('#reset').onclick = () => { if (confirm('Delete ALL data?')) { S = empty(); save(); render(); toast('All data cleared'); } };
render();
